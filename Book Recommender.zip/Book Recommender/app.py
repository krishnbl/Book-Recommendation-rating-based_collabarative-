from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np
from fuzzywuzzy import process

# Load pickle files
df = pickle.load(open('df.pkl', 'rb'))
pivot = pickle.load(open('pivot.pkl', 'rb'))
books = pickle.load(open('books.pkl', 'rb'))
similarity_score = pickle.load(open('similarity_score.pkl', 'rb'))

# Initialize Flask app
app = Flask(__name__)

# Home route
@app.route('/')
def index():
    return render_template('index.html',
                           book_name=list(df['Book-Title'].values),
                           author=list(df['Book-Author'].values),
                           image=list(df['Image-URL-M'].values),
                           votes=list(df['num_rating'].values),
                           rating=list(df['avg_rating'].values))

# Recommendation UI route
@app.route('/recommend')
def recommend_ui():
    return render_template('recommend.html')

# Auto-suggestion route
@app.route('/auto_suggest', methods=['GET'])
def auto_suggest():
    query = request.args.get('query')
    # Get best matches from book titles using fuzzywuzzy
    if query:
        suggestions = process.extract(query, df['Book-Title'], limit=5)
        return jsonify(suggestions)
    return jsonify([])

# Recommendation processing route
@app.route('/recommend_books', methods=['POST'])
def recommend():
    user_input = request.form.get('user_input')
    
    # Check if the book exists exactly or use fuzzywuzzy for closest match
    match = process.extractOne(user_input, df['Book-Title'])
    if match[1] < 70:  # If the match score is below a certain threshold, no match is found
        message = "Searched book is not present."
        return render_template('recommend.html', message=message)

    # Get index of the matched book
    index = np.where(pivot.index == match[0])[0][0]
    similar_items = sorted(list(enumerate(similarity_score[index])), key=lambda x: x[1], reverse=True)[1:5]
    
    data = []
    for i in similar_items:
        item = []
        temp_df = books[books['Book-Title'] == pivot.index[i[0]]]
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Book-Title'].values))
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Book-Author'].values))
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Image-URL-M'].values))
        
        data.append(item)

    return render_template('recommend.html', data=data)
    
# Run the application
if __name__ == '__main__':
    app.run(debug=True)
